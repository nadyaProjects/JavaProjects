package edu.pragmatic;

public interface QA {

    void verifyQuality();
}
