package edu.pragmatic;

public interface SystemAdmin {

    void configureMachine();

    void supportSoftware();
}
