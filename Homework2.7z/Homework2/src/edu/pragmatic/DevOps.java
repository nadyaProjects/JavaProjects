package edu.pragmatic;

public class DevOps implements Developer, SystemAdmin {
    @Override
    public void buildSoftware() {

    }

    @Override
    public void makeCodeReview() {

    }

    @Override
    public void configureMachine() {

    }

    @Override
    public void supportSoftware() {

    }
}
