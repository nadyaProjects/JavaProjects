package edu.pragmatic;

public class CTO implements Developer, SystemAdmin, QA, Manager {

    @Override
    public void buildSoftware() {

    }

    @Override
    public void makeCodeReview() {

    }

    @Override
    public void verifyQuality() {

    }

    @Override
    public void configureMachine() {

    }

    @Override
    public void supportSoftware() {

    }

    @Override
    public void managePeople() {

    }

}
