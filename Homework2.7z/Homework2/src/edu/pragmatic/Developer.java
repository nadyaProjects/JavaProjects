package edu.pragmatic;

public interface Developer {

    void buildSoftware();

    void makeCodeReview();

}
