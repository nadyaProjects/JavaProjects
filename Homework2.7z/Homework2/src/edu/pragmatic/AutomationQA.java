package edu.pragmatic;

public class AutomationQA implements QA {
    @Override
    public void verifyQuality() {

    }

    void writeAutomationTests() {

    }
}
